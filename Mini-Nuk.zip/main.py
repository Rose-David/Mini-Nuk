print("script started")
import datetime
print(datetime.datetime.now())
import discord
import os
import asyncio
from alwayson import keepalive
import flask
import random

client = discord.Client()

@client.event
@asyncio.coroutine 
def on_ready():
    print(client.user, ": ready")
    yield from client.change_presence(game=discord.Game(name='by myself cuz i dont have friends | N:help'))

@client.event
@asyncio.coroutine
def on_message(message):
  help_doc = open('help.txt', 'r')
  if message.author != client.user:
    if message.content.startswith('N:rev ') or message.content.startswith('n:rev '):
      message_just_prefix_rev = message.content[0:5]
      message_no_prefix_rev = message.content.replace(message_just_prefix_rev,"")
      yield from client.send_message(message.channel, message_no_prefix_rev[::-1])
      print('successful rev excecuted   ', datetime.datetime.now())
    elif message.content.startswith("N:rng ") or message.content.startswith('n:rng '):
      message_just_prefix_rng = message.content[0:5]
      message_no_prefix_rng = message.content.replace(message_just_prefix_rng,"")
      message_no_prefix_rng_listone, message_no_prefix_rng_listtwo = (message_no_prefix_rng.split(", "))
      message_no_prefix_rng_num = (random.randint(int(message_no_prefix_rng_listone), int(message_no_prefix_rng_listtwo)))
      yield from client.send_message(message.channel, message_no_prefix_rng_num)
      print('successful rng executed   ', datetime.datetime.now())
    elif message.content.startswith('N:8ball ') or message.content.startswith('n:8ball '):
      eight_ball_list = ('It is physically impossible.', 'Not a chance.', 'just no.', 'no.', 'Probably not.', 'About 50/50', 'Even chance.', 'Perhaps.', 'Ok chance.', 'Probably.', 'Most Likely', '100% yeah.')
      if message.content != ('N:8ball is benny dumb?' or 'n:8ball is benny dumb?'):
         yield from client.send_message(message.channel, random.choice(eight_ball_list))
         print('successful 8ball excecuted   ', datetime.datetime.now())
      else:
        yield from client.send_message(message.channel, "absolutely, ncr 4 life, forget mr. ring-a-ding-ding")
        print(message.author, ' found the 8ball fallout: NV secret, and died. F.')
        exit()
    elif message.content.startswith('N:help') or message.content.startswith('N:commands') or message.content.startswith('n:help') or message.content.startswith('n:commands'):
      yield from client.send_message(message.channel, help_doc.read())
    elif message.content.startswith('N:branch') or message.content.startswith('n:branch'):
      yield from client.send_message(message.channel, "stable")

keepalive()
token = os.environ.get("TOKEN")
client.run(token)